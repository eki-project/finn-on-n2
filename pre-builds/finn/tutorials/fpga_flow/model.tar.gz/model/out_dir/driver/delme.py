print("hlaoo")
